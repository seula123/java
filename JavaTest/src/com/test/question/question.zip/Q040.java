package com.test.question;

import java.util.Scanner;

public class Q040 {
	
	public static void main(String[] args) {
		
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("시작 숫자: ");
		
		int begin = scan.nextInt();
		
		System.out.println("종료 숫자: ");
		
		int end = scan.nextInt();
		
		
		for (int = begin; i<=end; i++) {
			
			
			
			
		}
		
	}

}
