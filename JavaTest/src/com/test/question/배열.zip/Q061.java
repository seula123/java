package com.test.question;

import java.util.Scanner;

public class Q061 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int [] nums = new int[5];
		
		for (int i=0; i<nums.length; i++) {
		
			System.out.println("숫자: ");
			
			nums[i] = scan.nextInt();
	
		}//for
		
		
		for (int j=nums.length-1; j>=0; j--) {
			System.out.printf("nums[%d] = %d \n",j,nums[j]);
		}
		
		
		
	}//main
}
