package com.test.question;

import java.util.Arrays;
import java.util.Scanner;

public class Q065 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		String result = "";
		
		System.out.println("최대 범위: ");
		int maxNum = scan.nextInt();
		
		System.out.println("최소 범위: ");
		int minNum = scan.nextInt();
		
		int [] randomNums = new int[20];
		
		for (int i=0; i<randomNums.length; i++) {
			
			randomNums[i] = (int)((Math.random()*20)+1);
		}
		
		for (int j=0; j<randomNums.length; j++) {
			
			if (randomNums[j]>minNum && randomNums[j]<maxNum) {
				
				result = result + (randomNums[j]+",");
			}
			
		}
		
		System.out.printf("원본: %s \n",Arrays.toString(	));
		System.out.printf("결과: %s \n",result);
		
		
	}

}
