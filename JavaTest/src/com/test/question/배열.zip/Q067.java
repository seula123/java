package com.test.question;

import java.util.Arrays;
import java.util.Scanner;

public class Q067 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int[] nums = {5,6,2,4,3,8,7,4,10,9};
		
		System.out.println("삽입 위치: ");
		int place = scan.nextInt();
		
		System.out.println("값: ");
		int input = scan.nextInt();
		
		System.out.println(Arrays.toString(nums));
		
		if (nums[place]!=0) {
			for (int i=nums.length-1; i>place; i--) {
				nums[i] = nums[i-1];
				
			}
		}
		nums[place] = input;
		System.out.println(Arrays.toString(nums));
	}

}
