package com.test.question;

import java.util.Arrays;
import java.util.Scanner;

public class Q068 {
	
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		int stack = 0;
		
		int[] nums = {5,6,1,3,2,8,7,4,10,9};
		
		System.out.print("삭제 위치: ");
		int place = scan.nextInt();
		
		System.out.println(Arrays.toString(nums));
		
		for (int i=place; i<nums.length-1; i++) {
			
			nums[i] = nums[i+1]; //앞에 뒤의 값을 복사
			stack = i; 
			
		}
		nums[stack+1] = 0; //마지막자리에 0 넣기
		System.out.println(Arrays.toString(nums));
	}

}
